// تفعيل تأثيرات الحركة عند التمرير
window.addEventListener('scroll', () => {
    const scrollPosition = window.scrollY;
    const windowHeight = window.innerHeight;
    
    // شريط التقدم
    const scrollTop = document.documentElement.scrollTop;
    const scrollHeight = document.documentElement.scrollHeight;
    const clientHeight = document.documentElement.clientHeight;
    const scrollPercent = (scrollTop / (scrollHeight - clientHeight)) * 100;
    document.querySelector('.progress-bar').style.width = scrollPercent + '%';
    
    // زر العودة للأعلى
    const backToTop = document.getElementById('backToTop');
    if (window.scrollY > 300) {
        backToTop.style.display = 'block';
    } else {
        backToTop.style.display = 'none';
    }
    
    // تأثيرات الحركة للعناصر
    document.querySelectorAll('.animate').forEach((element, index) => {
        const elementPosition = element.getBoundingClientRect().top + scrollTop;
        
        if (scrollTop > elementPosition - windowHeight + 100) {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }
    });
});

// زر العودة للأعلى
document.getElementById('backToTop').addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// قائمة الجوال
document.querySelector('.hamburger').addEventListener('click', () => {
    document.querySelector('.mobile-nav').classList.toggle('active');
});

// حفظ بيانات النموذج في localStorage
const contactForm = document.getElementById('contactForm');
const formInputs = contactForm.querySelectorAll('input, textarea, select');

// تحميل البيانات المحفوظة
formInputs.forEach(input => {
    const savedValue = localStorage.getItem(`form_${input.name}`);
    if (savedValue) {
        input.value = savedValue;
    }
});

// حفظ البيانات عند الكتابة
formInputs.forEach(input => {
    input.addEventListener('input', () => {
        localStorage.setItem(`form_${input.name}`, input.value);
    });
});

// التحقق من النموذج وإرساله
contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // التحقق من البريد الإلكتروني
    const email = this.querySelector('input[type="email"]').value;
    if (!email.includes('@')) {
        alert('الرجاء إدخال بريد إلكتروني صحيح!');
        return;
    }
    
   
    // مسح البيانات بعد الإرسال الناجح
    formInputs.forEach(input => {
        localStorage.removeItem(`form_${input.name}`);
    });
    
    alert('تم استلام طلبك بنجاح، سنتواصل معك في أقرب وقت!');
    this.reset();
    
    if (typeof grecaptcha !== 'undefined') {
        grecaptcha.reset();
    }
});

// تبديل الوضع الداكن
const darkModeToggle = document.getElementById('darkModeToggle');
const body = document.body;

// تحقق من التفضيل المحفوظ
if (localStorage.getItem('darkMode') === 'enabled') {
    body.classList.add('dark-mode');
    darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
}

// حدث التبديل
darkModeToggle.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    
    if (body.classList.contains('dark-mode')) {
        localStorage.setItem('darkMode', 'enabled');
        darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    } else {
        localStorage.setItem('darkMode', 'disabled');
        darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    }
});

// شريط التمرير للآراء
let isDragging = false;
let startX, scrollLeft;
const slider = document.querySelector('.testimonial-slider');

slider.addEventListener('mousedown', (e) => {
    isDragging = true;
    startX = e.pageX - slider.offsetLeft;
    scrollLeft = slider.scrollLeft;
    slider.style.cursor = 'grabbing';
});

slider.addEventListener('mouseleave', () => {
    if (isDragging) {
        isDragging = false;
        slider.style.cursor = 'grab';
    }
});

slider.addEventListener('mouseup', () => {
    isDragging = false;
    slider.style.cursor = 'grab';
});

slider.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    e.preventDefault();
    const x = e.pageX - slider.offsetLeft;
    const walk = (x - startX) * 2;
    slider.scrollLeft = scrollLeft - walk;
});

// تفعيل تأثيرات الحركة عند التحميل
window.addEventListener('load', () => {
    document.querySelectorAll('.animate').forEach(el => {
        el.style.opacity = '0';
    });
    
    const windowHeight = window.innerHeight;
    document.querySelectorAll('.animate').forEach((element, index) => {
        const elementPosition = element.getBoundingClientRect().top;
        
        if (elementPosition < windowHeight - 100) {
            setTimeout(() => {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }, index * 200);
        }
    });
    
    // تغيير اللون حسب الوقت
    const hour = new Date().getHours();
    if ((hour > 18 || hour < 6) && localStorage.getItem('darkMode') !== 'disabled') {
        body.classList.add('dark-mode');
        darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }
});