/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;
import java.util.Scanner;

class Array11D<T> {
    private static Object[] data = new Object[10]; 
    private static Scanner sc = new Scanner(System.in);
private int size =0;//
    void insert() {
        System.out.println( "enter the element of array (numbers or vaitables):");
        for (int i = 0; i < data.length; i++) {
            data[i] = sc.next(); 
       
        size++;//
        if(i==data.length-1)break;
        
        }
    }

    void display() {
        System.out.println("the element of array:");
        for (Object element : data) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
  
    

    void deleteItem(T item) {
        int index = -1;
        Boolean found = false;

        for (int i = 0; i < data.length; i++) {
            if (data[i].equals(item)) {
                index = i;
                found = true;
                break;
            }
        }

        if (found) {
            for (int i =index; i < data.length-1; i++) {
                data[i] = data[i+1];
            }
            data[data.length -1] = 0; size--; 
            
            
            
            System.out.println("تم حذف العنصر [" + item + "] بنجاح.");
        } else {
            System.out.println("العنصر [" + item + "] غير موجود.");
        }
    }

    public T getMax() {
        T max = (T) data[0];
        for (Object element : data) {
            if (element instanceof Comparable) {
                if (((Comparable) element).compareTo(max) > 0) {
                    max = (T) element;
                }
            }
        }
        return max;
    }

    public double getSum() {
        double sum = 0;
        for (Object element : data) {
            if (element instanceof Number) {
                sum += ((Number) element).doubleValue();
            } else {
                try {
                    sum += Double.parseDouble(element.toString());
                } catch (NumberFormatException e) {
           
                }
            }
        }
        return sum;
    }

    public double getAvg() {
        return getSum() / data.length;
    }

    public T getMin() {
        T min = (T) data[0];
        for (Object element : data) {
            if (element instanceof Comparable) {
                if (((Comparable) element).compareTo(min) < 0) {
                    min = (T) element;
                }
            }
        }
        return min;
    }
   
    
    

    void deleteAllOccurrences(T item) {
        Boolean found = false;

        for (int i = 0; i < data.length; i++) {
            if(data[i].equals(item)) {
                found = true;
                for(int j = i; j < data.length-1; j++) {
                    data[j] = data[j+1];
                }
                data[data.length-1]= 0;     
                i--; size--; 
            }
        }

        if (found) {
            System.out.println("تم حذف جميع التكرارات للعناصر [" + item + "] بنجاح.");
        } else {
            System.out.println("العنصر [" + item + "] غير موجود");
        }
    }
}









class ArrayD2<T> {
    private Scanner sc = new Scanner(System.in);
    private int row;
    private int col;
    private T[][] data;

   

    public ArrayD2() {
        this.row = 3;
        this.col = 3;
        data = (T[][]) new Object[row][col];
    }

    
    public void create(int rows, int cols) {
        row = rows;
        col = cols;
        data = (T[][]) new Object[row][col];
    }

   
    public void insert() {
        System.out.println("enter the element of array two:");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                System.out.print("أدخل العنصر في الموقع [" + i + "][" + j + "]: ");
                data[i][j] = (T) sc.next(); 
            }
        }
    }

    
    public T getMax() {
        T max = data[0][0];
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                if (((Comparable<T>) data[i][j]).compareTo(max) > 0) {
                    max = data[i][j];
                }
            }
        }
        return max;
    }

    
    public double getSum() {
        double sum = 0;
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                sum += Double.parseDouble(data[i][j].toString());
            }
        }
        return sum;
    }

  
    public double getAvg() {
        return getSum() / (row * col);
    }

    
    public T getMin() {
        T min = data[0][0];
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                if (((Comparable<T>) data[i][j]).compareTo(min) < 0) {
                    min = data[i][j];
                }
            }
        }
        return min;
    }
    public int[] search(T val) {
        int[] result = new int[]{0, -1, -1}; 
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
               
                if (data[i][j] != null && data[i][j].equals(val)) {
                    result[0] = 1; 
                    result[1] = i; 
                    result[2] = j; 
                    //return result;
               break; }
            }  if (result[0]==1) {
        break;    
        }
        }
        return result; 
    }

   
    public void delete(T item) {
        int[] r = search(item);
        int i = r[1];
        int j = r[2];
        if (r[0] == 1) {
            for (int k = j; k < data[i].length-1; k++) {
                data[i][k] = data[i][k+1];
            }
            data[i][data[i].length-1] = null; 
            System.out.println("seccessfull");
        } else {
            System.out.println("العنصر [" + item + "] غير موجود");
        }
    }

   
    public void display() {
        System.out.println("element of array two");
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                System.out.print(data[i][j] + " ");
            }
            System.out.println();
        }
    }} 
    






class ArrayLists<T> {
    static Scanner sc = new Scanner(System.in);
    private int current; 
    private T[] data; 

    
    public ArrayLists() {
        this(50); 
    }

    
    public ArrayLists(int size) {
        current = -1;
        data = (T[]) new Object[size];
    }

    public boolean isFull() {
        return current == data.length-1; 
    }

    public boolean isEmpty() {
        return current == -1; 
    }

    public void add(T val) {
        if (isFull()) {
            System.out.println("array full");
            return;
        }
        current++;
        data[current] = val; 
    }

    public void display() {
        if (isEmpty()) {
            System.out.println("array Empty");
        } else {
            System.out.println(" the element of arraylist:");
            for (int i = 0; i <= current; i++) {
                System.out.println(data[i] + " ");
            }
        }
    }

    public int search(T val) {
        if (isEmpty()) {
            System.out.println("arraylist is Empty");
            return -1;
        }
        for (int i = 0; i <= current; i++) {
            if (data[i].equals(val)) {
                return i; 
            }
        }
        return -1; 
    }


    public void delete(T item) {
        int res = search(item);
        if (res != -1) {
            for (int i = res; i < current; i++) {
                data[i] = data[i + 1]; 
            }
            data[current] = null;
            current--; 
        } else{
            System.out.println("العنصر [" + item + "] غير موجود");
        }
    }

    public int length() {
        return current + 1;
    }
}





class StackADTT<T> {
    static Scanner sc = new Scanner(System.in);
    private T[] stack;
    private int top;

    
    public StackADTT() {
        this(10); 
    }

    
    public StackADTT(int size) {
        this.stack = (T[]) new Object[size]; 
        this.top = -1; 
    }

    public boolean isFull() {
        return top == stack.length-1; 
    }

    public boolean isEmpty() {
        return top == -1; 
    }

    public void push(T value) {
        if (isFull()) {
            System.out.println("stack is full");
            return;
        }
        stack[++top] = value;
    }

    public T pop() {
        if (isEmpty()) {
            System.out.println("stack is empty");
            return null;
        }
        return stack[top--]; 
    }

    public T peek() {
        return (isEmpty() ? null : stack[top]); 
    }

    public void print() {
        for (int i = top; i >= 0; i--) {
            System.out.println("{" + stack[i] + "}");
        }
    }

    public int getSize() {
        return top + 1; 
    }

    public void delete(T item) {
        if (isEmpty()) {
            System.out.println("stack is empty");
            return;
        }
        StackADTT<T> tempStack = new StackADTT<T>(this.getSize());
        while (!isEmpty()) {
            if (peek().equals(item)) {
                System.out.println("item is deleted:" + pop());
                break;
            }
            tempStack.push(pop()); 
        }
        while (!tempStack.isEmpty()) {
            push(tempStack.pop()); 
        }
    }

    public void transfer() {
        if (isEmpty()) {
            System.out.println("stack is empty");
            return;
        }
        StackADTT<T> tempStack1 = new StackADTT<T>();
        StackADTT<T> tempStack2 = new StackADTT<T>();
        while (!isEmpty()) {
            tempStack1.push(pop());
        }
        while (!tempStack1.isEmpty()) {
            tempStack2.push(tempStack1.pop());
        }
        while (!tempStack2.isEmpty()) {
            push(tempStack2.pop());
        }
    }
}







  class Studentt {
    public String Name;
    public int id;
    public String Birthdate;
    public String Department;
    public double avg;

   
      @Override
    public String toString() {
        return "Student{" + "Name='" + Name + '\'' + ", id=" + id + ", Birthdate='" + Birthdate + '\'' + ", Department='" + Department + '\'' + ", avg=" + avg + '}';
    }
}







class QueueG<T> {
    int rear;
    int front;
    T data[];

    public QueueG(int size) {
        rear = front = -1;
        data = (T[]) new Object[size];
    }

   
  
    boolean isFull() {
        return rear == data.length-1;
    }

    boolean isEmpty() {
        return front == rear;
    }

    public void enQueue(T val) {
        if (isFull()) {
            System.out.println("The queue is full");
            return;
        }
        rear++;
        data[rear] = val;
    }

    public T deQueue() {
        if (isEmpty()) {
            System.out.println("The queue is empty");
            return null;
        }
        front++;
        return data[front];
    }

    public T geFront() {
        if (isEmpty()) {
            System.out.println("The queue is empty");
            return null;
        }
        return data[front + 1];
    }

    public T geRear() {
        if (isEmpty()) {
            System.out.println("The queue is empty");
            return null;
        }
        return data[rear];
    }

    public void display() {
        if (isEmpty()) {
            System.out.println("The queue is empty");
            return;
        }
        System.out.println("Queue contents:");
        for (int i = front + 1; i <= rear; i++) {
            System.out.println(data[i]);
        }
    }
}



class Students {
    static Scanner sc = new Scanner(System.in);
    public String name;
    public int id;
    public String birthdate;
    public String department;
    public double avg;

    @Override
    public String toString() {
        return "Student{" + "name='" + name + '\'' + ", id=" + id + ", birthdate='" + birthdate + '\'' + ", department='" + department + '\'' + ", avg=" + avg + '}';
    }
}

class CircularQueuee<T> {
    private int rear;
    private int front;
    private int cont;
    private T data[];

    public CircularQueuee() {
        this(20);
    }

    public CircularQueuee(int size) {
        this.data = (T[]) new Object[size];
        this.rear = -1;
        this.front = 0;
        this.cont = 0;
    }

    boolean isFull() {
        return (front + 1) % data.length == rear;
    }

    boolean isEmpty() {
        return front == rear;
    }

    public void enQueue(T val) {
        if (isFull()) {
            System.out.println("The queue is full");
            return;
        }
        rear = (rear + 1) % data.length;
        data[rear] = val;
        cont++;
    }

    public T deQueue() {
        if (isEmpty()) {
            System.out.println("The queue is empty");
            return null;
        }
        T item = data[front];
        front = (front + 1) % data.length;
        cont--;
        return item;
    }

    public T getFront() {
        if (isEmpty()) {
            System.out.println("The queue is empty");
            return null;
        }
        return data[(front + 1) % data.length];
    }

    public T getRear() {
        if (isEmpty()) {
            System.out.println("The queue is empty");
            return null;
        }
        return data[rear];
    }

    public void display() {
        if (isEmpty()) {
            System.out.println("The queue is empty");
            return;
        }
        System.out.println("Queue contents:");
        for (int i = 0; i < cont; i++) {
            System.out.println(data[(front + 1 + i) % data.length]);
        }
    }
}








public class Generics {
 
 static Scanner sc =new Scanner (System.in);
    
    public static void main(String[] args) 
    {

      
        Array11D<String> D1;
        D1 = new Array11D<String>();
        
       ArrayD2<String> D2 = new ArrayD2<String>(); 

         ArrayLists<Object> list = new ArrayLists<Object>();           
         
        StackADTT<Object> stack = new StackADTT<Object>(); 
         
          Studentt sd = new Studentt();
       
          
       
      for(int j = 1 ; j <=8 ;j++){   
       
        System.out.println("Generics");
        System.out.println("******************************************");
    
        System.out.println("******************************************");
        System.out.println("[01] - Owe Dimenstional Array");
        System.out.println("[02] - Two Dimenstional Array");
        System.out.println("[03] - ArrayList Using Array ");
        System.out.println("[04] - Stack ");
        System.out.println("[05] - Linear Queue");
        System.out.println("[06] - circular Queue");      
        System.out.println("[0] - Exit ");
        
       int t = sc.nextInt();
        
      switch(t){
      
       case 1:{
          for(int k = 1 ; k <=8 ;k++){   
       
        System.out.println("Operation of One Array");
        System.out.println("******************************************");
        System.out.println("[01] - insert Array");
        System.out.println("[02] - display");
        System.out.println("[03] - maximum value");
        System.out.println("[03] - minimum value ");
        System.out.println("[03] - sum and avg");
        System.out.println("[04] - deletItem "); 
        System.out.println("[05] - delet Aii Iteration ");          
        System.out.println("[0] - Exit ");
        
       int v = sc.nextInt();
        
      switch(v){
            
       case 1:{ 
        
        D1.insert();
      
                break;} 
      
       case 2 :{
            D1.display();
          break; 
          }      
         
       case 3 :{
        System.out.println(" MAX is : " + D1.getMax());
        System.out.println(" MIN is : " + D1.getMin());
        System.out.println(" SUM is : " + D1.getSum());
        System.out.println(" Avg  s : " + D1.getAvg());
          break; 
          }      
           
      case 4 :{
        System.out.println(" Enter the element to deleted:");
        String d = sc.next();
        D1.deleteItem(d);

          break; 
          }        
         
      case 5 :{
            
        System.out.println("أدخل العنصر لحذف جميع التكرارات:");
        String f = sc.next();
        D1.deleteAllOccurrences(f);
     
          break; 
          }    
          case 0:{
               System.exit(0);
            break;}
      default :{
              System.out.println("Choose an Error,Choose again");
          
          }        
      }}
   break;   }
      
       
       case 2:{
           
          for(int k = 1 ; k <=8 ;k++){   
       
        System.out.println("Operation of two Array");
        System.out.println("******************************************");
        System.out.println("[01] - insert Array");
        System.out.println("[02] - display");
        System.out.println("[03] - deletItem ");
        System.out.println("[04] - search of element ");
        System.out.println("[05] - sum and avg");
    
                 
        System.out.println("[0] - Exit ");
        
       int v = sc.nextInt();
        
      switch(v){
                     
       case 1:{ 
           
        System.out.println("enter the element of array");
        int r = sc.nextInt();
        int c = sc.nextInt();
        D2.create(r, c);

        D2.insert();
           
         
            break;}
           
       case 2:{
          
           D2.display();
           
           break;}   
           
           
       case 3:{
           
           
        System.out.println("enter the item of deleled :");
        String g = sc.next();
        D2.delete(g);

         D2.display();  
           
           break;}     
       case 4 :{
           
           
        System.out.println("enter thr item you atr search:");
        String h = sc.next();
        int[] check = D2.search(h);
        if (check[0] == 1) {
            System.out.println(v + " موجود في الموقع: [" + check[1] + "][" + check[2] + "]");
        } else {
            System.out.println("no found");
        }
           
           break;} 
           
       case 5:{
           
           
        System.out.println("Sum is  = " + D2.getSum());
         System.out.println(" Avg " + D2.getAvg());
        System.out.println("MAX is = " + D2.getMax());
        System.out.println("Min is = " + D2.getMin());
        
           break;} 
           
           
           
           
       case 0:{
               System.exit(0);
            break;}
      default :{
              System.out.println("Choose an Error,Choose again");
          
          }      
                   
           
           
           
      }}           
            break;} 
                     
            
           
           
           
       case 3:{ 
           
           
             
            
       
        System.out.println("Operation of ArrayList");
        System.out.println("******************************************");
       
           
        System.out.println("enter the sise");
        int size = sc.nextInt();
        list = new ArrayLists<Object>(size); 
     
        System.out.println("e data enter (Write the'exit') to go out :");
        sc.nextLine(); 
        while (true) {
            String input = sc.nextLine();
            if (input.equalsIgnoreCase("exit")) {
                break;
            }
            list.add(input);
        }
           list.display();
  
    
        System.out.println("enter the data you are search:");
        String searchItem = sc.nextLine();
        int check = list.search(searchItem);
        if (check >= 0) {
            System.out.println("the element is fond in site---> :" + check);
        } else{
            System.out.println("no founf:");
        }
  
            
        System.out.println("enter the element you are deleted:");
        String deleteItem = sc.nextLine();
        list.delete(deleteItem); 
        
              System.out.println("Size of data -->:" + list.length());
        
       
            break;}
           
           
           
       case 4:{
           
          for(int k = 1 ; k <=8 ;k++){   
       
        System.out.println("Operation of Stack");
        System.out.println("******************************************");
        System.out.println("[01] - insert size fo stack");
       
        System.out.println("[02] - display");
        System.out.println("[03] - deletItem (pop) and top");
        System.out.println("[04] - deletItem of elementstack ");
        System.out.println("[05] - transtive of stack");
    
                 
        System.out.println("[0] - Exit ");
        
       int v = sc.nextInt();
        
      switch(v){
     
          
        case 1:{
            System.out.println("enter the size of :");
        int size = sc.nextInt();
        stack = new StackADTT<Object>(size);   
            
        System.out.println("enter the element of stsck:");
       // size =stack.getSize();
        for (int i = 0; i < size; i++) {
            Object element = sc.next(); 
            stack.push(element); 
        } 
        
          break ;
          
          }   
        
          
        case 2:{
            stack.print();
            
             
            break;}   
        
        case 3:{
            
             System.out.println("item is deleted:"+ stack.pop());
             System.out.println(" Top element :" + stack.peek());

            
            break;}    
          
        case 4:{
        System.out.println("enter the element to deleted");
        Object deleteItem = sc.next();
        stack.delete(deleteItem);
        stack.print();
            
            break;}
            
          case 5:{
            
        System.out.println("-------------------");
        System.out.println("Transfer");
        stack.transfer(); 
        stack.print(); 
            
            break;}    
            
            
            
      }}
           
     break; }
           
       case 5:{
           
           
         System.out.println("Enter Size:");
        int size = sc.nextInt();
        QueueG Qeue = new QueueG<Studentt>(size);

        
        for (int i = 0; i < size; i++) {
            sd = new Studentt();
            System.out.println("Enter the name:");
            sd.Name = sc.next();
            System.out.println("Enter the department:");
            sd.Department = sc.next();
            System.out.println("Enter the id:");
            sd.id = sc.nextInt();
            System.out.println("Enter the average:");
            sd.avg = sc.nextDouble();

            Qeue.enQueue(sd);
        }

      
        Qeue.display();

      
        Qeue.deQueue();
        System.out.println("Front of the queue: " + Qeue.geFront());
        System.out.println("Rear of the queue: " + Qeue.geRear());
           
           
           
           
           break;}   
       case 6:{
       
           System.out.println("Enter the size:");
        int size = sc.nextInt();

        CircularQueuee<Students> cq = new CircularQueuee<Students>(size);
          
        for (int i = 0; i < size; i++) {
            Students stud = new Students(); 
            System.out.println("Enter the name:");
            stud.name = sc.next();

            System.out.println("Enter the department:");
            stud.department = sc.next();

            System.out.println("Enter the birthdate:");
            stud.birthdate = sc.next();

            System.out.println("Enter the ID:");
            stud.id = sc.nextInt();

            System.out.println("Enter the average:");
            stud.avg = sc.nextDouble();

            cq.enQueue(stud);
        }

     
        cq.display();

      
        System.out.println("Front: " + cq.getFront());
        System.out.println("Rear: " + cq.getRear());
           
           
           
      break; 
       }  
           
           
           
           
           
       case 0:{
               System.exit(0);
            break;}
      default :{
              System.out.println("Choose an Error,Choose again");
          
          }      
              
      
      }}
      
        
       
    }  
    

}
