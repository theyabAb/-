
package project1;


import java.util.Scanner;

public class Project1 {

   
    static Scanner sc =new Scanner(System.in);
    public static void main(String[] args) {
       
      Array1D D1 = new Array1D();  
     
      Array2D D2 = new Array2D();
    
      ArrayList List = new  ArrayList();
    
     StackADT stack = new StackADT();
    
     Queue Qu = new Queue();
     Student sd = new Student();
    
       CircularQueue cq = new CircularQueue(6);
     Studen cgg = new Studen();
     
    
     
     
     
     for(int i = 0;i<=10 ;i++){
         
        System.out.println("All Data Structure Array");
        System.out.println("******************************************");
        System.out.println("[01] - Owe Dimenstional Array");
        System.out.println("[02] - Two Dimenstional Array");
        System.out.println("[03] - ArrayList Using Array ");
        System.out.println("[04] - Stack ");
        System.out.println("[05] - Linear Queue");
        System.out.println("[06] - circular Queue");
        System.out.println("[07] - Java Generics Programs");
        System.out.println("[08] - Lineed List");
        //System.out.println("[09] - Lineed Stack ");
        //System.out.println("[10] - Lineed Queue  ");
        //System.out.println("[11] - Double Lineed List ");
        //System.out.println("[12] -All Data Structure Using Generics  ");
        System.out.println("[0] - Exit ");
        
        int ch = sc.nextInt();
        
      switch(ch){
        
          
          
        case 1:{
            for(int j = 1 ; j <=8 ;j++){   
       
        System.out.println("Operation of One Array");
        System.out.println("******************************************");
        System.out.println("[01] - insert Array");
        System.out.println("[02] - display");
        System.out.println("[03] - deletItem ");    
        System.out.println("[04] - maximum value");
        System.out.println("[05] - minimum value ");
        System.out.println("[06] - sum and avg");
         //System.out.println("[0] - avg ");
        System.out.println("[07] - delet Aii Iteration ");          
        System.out.println("[0] - Exit ");
        
       int t = sc.nextInt();
        
      switch(t){
      
      
        case 1:{
          
            D1.insert();
                         break;
        }  
         
        case 2:{
                
           D1.display();     
                
            break;
            
            
        }  
            
        case 3:{
                 
        System.out.println("Enetr element to delete");
                 
          int d = sc.nextInt();
             D1.deletItem(d);
                
            break;
        } 
        case 4:{
        System.out.println("the max elements "+D1.getMax());
        break;
        }   
             
        case 5:{
        System.out.println("the min elements "+D1.getMin());
        break;
        }      
            
        case 6:{
            System.out.println("the sum of elements "+D1.getSum());
        
            System.out.println("the avg of elements "+D1.getavg());
        break;
        }    
            
        case 7:{
            System.out.println("enter the element ");
              int d =sc.nextInt();
            D1.deletAllIteration(d);
           
        
        break;
        }     
          case 0:{
             
              System.exit(0);
                   
               break;
          
          }
          default :{
              
              System.out.println("Choose an Error,Choose again");
          
             }      
       
        }
     }
           
            break;
          }
           
            
            
         case 2:{
             
             for(int j = 1 ; j <= 6 ;j++){   
       
        System.out.println("Operation of two Array");
        System.out.println("******************************************");
        System.out.println("[01] - insert Array");
        System.out.println("[02] - display");
        System.out.println("[03] - deletItem ");    
        System.out.println("[04] - searsh");
        System.out.println("[05] - Sum and avg ");
      
        System.out.println("[06] - delet Aii Iteration ");          
         System.out.println("[07] -  ");
        System.out.println("[0] - Exit ");
        
       int t = sc.nextInt();
        
      switch(t){
       case 1:{
       System.out.println("enter row and col of array");  
        int r=sc.nextInt(); 
       int c =sc.nextInt();
       D2.create(r,c );
           
           D2.insert();
           
            break;}  
            
             case 2:{
                 D2.displiy();
            break;} 
            
             case 3:{
             System.out.println("enret the value to delet");
                 t=sc.nextInt();
                D2.delete(t);
            break;} 
            
            
            case 4:{
              System.out.println("enter the value you search"); 
             int s=sc.nextInt();  
             int check[]=D2.search(s); 
                if (check[0]==1) {
                    System.out.println(s+"is found"+" "+"index his"+check[1]+check[2]);  
                }
                else{
                    System.out.println("no found");
                }
            break;}  
            case 5:{
                System.out.println("sum = "+D2.getSum());
                 System.out.println("sum = "+D2.getAvg());
            break;}  
            
             case 6:{
          D2.change();
          
               System.out.println("enter the element ");
              int d =sc.nextInt();
            D2.deletall(d);  
          D2.displiy();
            D2.change2();
             D2.displiy();
         
         
            break;} 
                 
            case 7:{
                
               D2.change();
          
               System.out.println("enter the element ");
              int d =sc.nextInt();
            D2.deletalle(d);  
          D2.displiy();
            D2.change2();
             D2.displiy();  
                
                
            break;} 
                
                 case 8:{
                    // D2.change2();
            break;} 
                     
                     
          case 12:{
            break;}             
          case 0:{
               System.exit(0);
            break;}
          default :{
              System.out.println("Choose an Error,Choose again");
          
          }      
      }}
            break;}     
            
            case 3:{
                for(int j = 1 ; j <= 6 ;j++){   
       
        System.out.println("Operation of Array List");
        System.out.println("******************************************");
        System.out.println("[01] - insert Array");
        System.out.println("[02] - searsh");
        System.out.println("[03] - deletItem ");    
        System.out.println("[04] - display");
        System.out.println("[05] - minimum value ");
        System.out.println("[06] - sum ");
        System.out.println("[07] - delet Aii Iteration ");          
        System.out.println("[0] - Exit ");
        
       int t = sc.nextInt();
        
      switch(t){
      
             case 1:{
                
                 System.out.println("enter the Data ");   
                 int val = sc.nextInt();
                 List.add(val);
                 
                 
                       break;} 
            
             case 2:{
                 System.out.println("enter the item to search");
                 int val = sc.nextInt();
                 int check =List.search(val);
                 if (check >0) {
                     System.out.println(" item is found"+check);   
                 }else{
                 
                     System.out.println("item is not found");  
                 }
                         break;} 
            
            
            case 3:{
                
                System.out.println("enter the item to remove");    
                int val = sc.nextInt();
                List.detel(val);
                
                        break;}  
            case 4:{
               List.display(); 
                
            break;}  
            
             case 5:{
                 System.out.println("the lise size"+" "+List.length());
            break;} 
                 
                        
          case 0:{
               System.exit(0);
            break;}
          default :{
              System.out.println("Choose an Error,Choose again");
          
          }
      
      
      }}
            break;}  
            
             case 4:{
                 for(int j = 1 ; j <= 6 ;j++){   
       
        System.out.println("Operation of Stack");
        System.out.println("******************************************");
        System.out.println("[01] - create stack");
        System.out.println("[02] - puch");
        System.out.println("[03] - display the top "); 
        System.out.println("[04] - pop ");     
        System.out.println("[05] - print ");
          System.out.println("[06] - delete ");
        System.out.println("[07] - transe ");
       
               
        System.out.println("[0] - Exit ");
        
       int t = sc.nextInt();
        
      switch(t){
       case 1:{
           System.out.println("enter the size"); 
           int size = sc.nextInt();
         stack = new StackADT(size);

            break;} 
            
            
            case 2:{
                 System.out.println("enter the element of stack");
                    int sk =sc.nextInt();
                    stack.push(sk);    
                 break;
            }  
           
            
            case 3:{
                System.out.println("TOP element"+stack.peek());  
                
            break;}  
            
             case 4:{
                 System.out.println("Popped :"+stack.pop());
            break;} 
                 
           
                
             case 5:{
              stack.print();  
                 
                 
            break;} 
                     
               case 6:{
                System.out.println("enter delet");
                int d=sc.nextInt();
                stack.delet(d);
            break;} 
                   
                   
                   
          case 7:{
              stack.transe();
            break;} 
          case 0:{
               System.exit(0);
            break;}
          default :{
              System.out.println("Choose an Error,Choose again");
          
          }      
      }}
            break;} 
            
             case 5:{
              for(int j = 1 ; j <=8 ;j++){   
       
        System.out.println("Operation of queue");
        System.out.println("******************************************");
       
        System.out.println("[01] - ensertn information of student and inequeue");
        
        System.out.println("[02] - print ");    
        System.out.println("[03] - dequeue ");
        System.out.println("[04] - getFront AND getRear ");
              
        System.out.println("[0] - Exit ");
        
       int t = sc.nextInt();
        
      switch(t){
      case 1:{
         
          
          System.out.println("Enter Size:");
        int size = sc.nextInt();
         Qu = new Queue(size);

          for (int k = 0; k < size; k++)                   
 {
             sd = new Student();
            System.out.println("Enter the name:");
            sd.Name = sc.next();
            System.out.println("Enter the department:");
            sd.Department = sc.next();
            System.out.println("Enter the id:");
            sd.id = sc.nextInt();
            System.out.println("Enter the average:");
            sd.avg = sc.nextDouble();

            Qu.enEqueue(sd);
        }
          
            break;} 
          
          
            case 2:{
             Qu.display();
            break;}  
            
             case 3:{
                 
                 Qu.deQueue();
            break;} 
                  
                
             case 4:{
                 System.out.println("front : "+Qu.geFront()+" ");
                 System.out.println(" rear: "+Qu.geRear()+"");
            break;} 
                     
                     
                       
          case 0:{
               System.exit(0);
            break;}
          default :{
              System.out.println("Choose an Error,Choose again");
          
          }
      
      
      
      
      
      
      }}   
                 
                 
            break;} 
            
            
            case 6:{
                
                
                
              for(int j = 1 ; j <=8 ;j++){   
       
        System.out.println("Operation of circular queue ");
        System.out.println("******************************************");
        System.out.println("[01] - ensertn information of student");
        System.out.println("[02] - enquque");
        System.out.println("[03] - print ");    
        System.out.println("[04] - dequeue ");
        System.out.println("[05] - getFront AND getRear ");
        System.out.println("[06] - sum ");
        System.out.println("[07] - delet Aii Iteration ");          
        System.out.println("[0] - Exit ");
        
       int y = sc.nextInt();
        
      switch(y){
      
       case 1:{
            System.out.println("enter the name");
          String s=sc.next();
          cgg.Name = s;
          
           System.out.println("enter the dept");
           s=sc.next();
          cgg.Department =s;
                 
          
          System.out.println("enter the birth");
           s=sc.next();
          cgg.Birthdate =s;
                 
           System.out.println("enter the id");
           int id=sc.nextInt();
          cgg.id =id;
          
           System.out.println("enter the avg");
           double av=sc.nextDouble();
          cgg.avg =av;
          
         cq.enEqueue(cgg);
         
            break;} 
                 
            case 2:{
               
                cq.deQueue();
            break;} 
                
            case 3:{
                cq.display();
            break;} 
                     
                     
          case 4:{
              System.out.println(cq.geFront());
            break;}
           case 5:{
              System.out.println(cq.geRear());
            break;}   
              
              
          case 0:{
               System.exit(0);
            break;}
          default :{
              System.out.println("Choose an Error,Choose again");
          
          }     
      
                
            }}
            break;}  
            case 8:{
                
                
            LinkedList1.main(args);   
          
      
            break;}  
            
             case 7:{
              Generics.main(args);   
                 
            break;} 
                       
          case 0:{
               System.exit(0);
            break;}
          default :{
              System.out.println("Choose an Error,Choose again");
          
          }      
              
        }
         
        
     
     
     
     
    }
}
    }

