
package project1;

import java.util.Scanner;


class Student {
    static Scanner sc =new Scanner (System.in);
public String Name;
public int id;
public String Birthdate;
public String Department;
public double avg;



    @Override
    public String toString() {
        return "Student{" + "Name=" + Name + ", id=" + id + ", Birthdate=" + Birthdate + ", Department=" + Department + ", avg=" + avg + '}';
    }

   


    
   

}

public class Queue {
     static Scanner sc =new Scanner (System.in);
 int rear;
 int front;
 Student data[];
  
public Queue(){
   this(50);
}
    public Queue(int size) {
        rear= front =-1 ;
       
        data = new Student[size];
    }
 boolean isFull(){return rear==data.length-1;}
 
  boolean isEmpty(){return front==rear;}
 
 public void enEqueue(Student val){
     if (isFull()) {
         System.out.println("the queue is full");
         return ;
     }
     rear++;
 data[rear]=val;
 
 }
 
 public Student deQueue(){
 if (isEmpty()) {
         System.out.println("the queue is empty");
         return null ;
     }
 front++;
 return data[front];
 
 
 }
 
 public Student geFront(){
 if (isEmpty()) {
         System.out.println("the queue is empty");
         return null ;
     }
 return data[front+1];
 } 
 
 public Student geRear(){
 if (isEmpty()) {
         System.out.println("the queue is empty");
         return null ;
     }
 return data[rear];
 }
 
public void display(){

if(isEmpty()) {
         System.out.println("the queue is empty");
         return  ;
     }
    System.out.println("Queue contents");
    for (int i = front+1; i <=rear;i++ ){
   
        System.out.println(data[i]+" ");   
    }
} 
 
}
