
package project1;
import java.util.Scanner;

class Studen {
    static Scanner sc =new Scanner (System.in);
public String Name;
public int id;
public String Birthdate;
public String Department;
public double avg;

  
    @Override
    public String toString() {
        return "Studen{" + "Name=" + Name + ", id=" + id + ", Birthdate=" + Birthdate + ", Department=" + Department + ", avg=" + avg + '}';
    }
}

public class CircularQueue {

    
  static Scanner sc =new Scanner (System.in);
  private int rear;
   private int front;
  private int cont;
  private Studen data[];    
    
 public CircularQueue(){
  this(20);   
     
    
 }
 
public CircularQueue(int size){
  this.data = new Studen[size];
  this.rear = -1;
  this.front = 0;
  this.cont = 0;
} 
boolean isFull(){return (front+1)%data.length==rear;}
 
  boolean isEmpty(){return front==rear;} 
 
public void enEqueue(Studen val){
     if (isFull()) {
         System.out.println("the queue is full");
         return ;
     }
     rear=(rear+1)%data.length;
      data[rear]=val;
      cont++;
 }
 
 public Studen deQueue(){
 if (isEmpty()) {
         System.out.println("the queue is empty");
         return null;
     }
 Studen st =data[front];
 front=(front+1)%data.length;
 cont--;
 return st;

 } 
 
 
 public Studen geFront(){
 if (isEmpty()) {
         System.out.println("the queue is empty");
         return null ;
     }
 return data[(front+1)%data.length];
 } 
 
 public Studen geRear(){
 if (isEmpty()) {
         System.out.println("the queue is empty");
         return null ;
     }
 return data[rear];
 }
 
public void display(){

if(isEmpty()) {
         System.out.println("the queue is empty");
         return  ;
     }
    System.out.println("Queue contents");
    for (int i = front; i <=cont;i++ ){
        System.out.println(data[(front+1)%data.length]+" ");   
    }
} 

  

    

    
 
 
 
 
    
}
