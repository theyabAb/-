
package project1;

import java.util.Scanner;
public class Array1D {
   static int []data = new int[10];
 static Scanner sc =new Scanner (System.in);

void insert(){
    // Scanner sc =new Scanner (System.in);
    System.out.println("Enter array element");
   for (int i = 0; i < data.length; i++) {
      data[i] = sc.nextInt();   
    }
}

void display(){
    System.out.println("The Array Elements Are");
    for (int i = 0; i < data.length; i++) {
        System.out.print(data[i]+" ");   
    }   
}
void deletItem(int item){
int index = 0;
boolean found = false ;
    for (int i = 0; i < data.length; i++) {
        if (data[i]==item) {
         index = i;
         found = true;
         break;
        }
   
    }
    if (found) {
        for (int i = index; i < data.length-1; i++) {
           data[i] = data[i+1];
        }
        data[data.length-1] = 0;
        
        
    }else{
    
        System.out.println("The Element ["+item +"is not found");
    
    }

}
public static int getMax(){
 int max=data[0];
    for (int i = 0; i < data.length; i++) {
        if (data[i]>max) {
            max = data[i];
            
        }
    }
    return max;
}

public int getSum(){
int sum = data[0];
    for (int i = 0; i < data.length; i++) {
       sum+=data[i]; 
    }
int s=(sum/data.length);
return sum  ;

}

public int getavg(){

int s=(getSum()/data.length);
return s  ;

}

public static int getMin(){
 int min=data[0];
    for (int i = 0; i < data.length; i++) {
        if (data[i]<min) {
            min = data[i];
            
        }
    }
    return min;
}


void deletAllIteration(int item){
int inde = 0;
boolean found = false ;
for (int i = 0; i < data.length; i++) {
        if (data[i]==item) {
         inde = i;
         found = true;
         
    for (int j = inde; j < data.length-1; j++) {
           data[j] = data[j+1];
        }
        data[data.length-1] = 0;
        i--;
       
        }
   
    }
    if (found) {
        System.out.println("successful");
        
    }else{
    
        System.out.println("The Element ["+item +"is not found");
    
    }

}

}

