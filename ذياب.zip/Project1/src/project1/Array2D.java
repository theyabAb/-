
package project1;


import java .util.Scanner;
public class Array2D {
 


private Scanner sc = new Scanner(System.in);
private int row;
private int col;
private int[][]data; 
private int[]array1;

    public Array2D() {
        this.row = 3;
        this.col = 3;
        data=new int[row][col];
        array1 = new int[row*col];
    }






//تهيئة المصفوفة 
public void create(int rows,int cols){
row = rows;
col = cols;
data = new int[row][col];
  array1=new int [row*col]; 

} 
    //داله ادخل العناصر
public void insert(){
    System.out.println("enter the element ot array ");
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
      data[i][j] = sc.nextInt();
      
                  
       }
   }
}

public int []search(int val){
int result[]=new int []{0,0,0};
    for (int i = 0; i < data.length; i++) {
        for (int j = 0; j < data[0].length; j++) {
            if (data[i][j]==val) {
            result[0]=1;
            result[1]=i;
            result[2]=j;
            break;
                
                
            }
   
        }
        if (result[0]==1) {
        break;    
        }
    }
return result;
}
public void delete(int item){
int r[]=search(item);
int i=r[1];
int j=r[2];
if(r[0]==1){

    for (int c = j; c < data[i].length-1; c++) {
      
        data[i][c]=data[i][c+1] ;
    }
data[i][data[i].length-1]=0;
    System.out.println("the element is deleted successfully");
}else{
    System.out.println("the item["+item+"] is not exist at all");

}


}



 int getMax(){
 int max=data[0][0];
    for (int i = 0; i < data.length; i++) {
       for (int j = 0; j < data[i].length; j++) { 
        if (data[i][j]>max) {
            max = data[i][j];
            
        }
    }
    }
    return max;
}
 
 
 int getSum(){
int sum = data[0][0];
    for (int i = 0; i < data.length; i++) {
     for (int j = 0; j < data[i].length; j++) {
   
        
    
         
       sum+=data[i][j]; 
    }}

return sum  ;

}

public int getAvg(){

int s=(getSum()/data.length);
return s  ;

}
 int getMin(){
 int min=data[0][0];
    for (int i = 0; i < data.length; i++) {
        for (int j = 0; j < data.length; j++) {
        if (data[i][j]<min) {
            min = data[i][j];
        }  
        }
    }
    return min;
}




  void change(){
   
    int co = 0;
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
       array1[co] = data[i][j] ;
       co++;
         
        }
    }
    System.out.println("changed from arr2 to arr1");
}


 
 //داله الحذف
void deletall(int newItem){
   
     boolean found = false ;

     int index = 0;
    for (int i = 0;i < array1.length; i++) {
        if (array1[i] == newItem) {
             found = true;     
           index = i;
            
           for (int j = index; j < array1.length-1; j++) {
           array1[j] = array1[j+1];     
            }
           array1[array1.length-1]=0;
           i--;   
        }   
    }
     if (found) {
         System.out.println("sucsse"); 
     }else{
         System.out.println(newItem +"NOT FOUND");
     }
      
    
    
    
}//حدف مع بقاء العنصر 
 void deletalle(int newItem){
   
     boolean found = false ;

     int index = 0;
    for (int i = 0;i < array1.length-3; i++) {
        if (array1[i] == newItem) {
             found = true;     
           index = i;
            
           for (int j = index; j < array1.length-3; j++) {
           array1[j] = array1[j+1];     
            }
           array1[array1.length-3]=0;
           i--;   
        }   
    }
     if (found) {
         System.out.println("sucsse"); 
     }else{
         System.out.println(newItem +"NOT FOUND");
     }
      
    
    
    
}
//داله نقل العناصر من الاحاديه الى الثنائيه
 void change2(){
     
     int cont = 0 ;
     for (int i = 0; i < data.length; i++) {
         for (int j = 0; j < data[i].length; j++) {
          data[i][j] = array1[cont] ;  
      cont++;
         } 
   
     }
 
 } 

//طباعه العناصر
 void displiy(){
     for (int i = 0; i < data.length; i++) {
         for (int j = 0; j < data[i].length; j++) {
             System.out.print(data[i][j]+" ");     
         }
         System.out.println();
     }
 
 }
    
    
    
    
    
    
    
}
