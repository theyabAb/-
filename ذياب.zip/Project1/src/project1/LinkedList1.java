
package project1;



import java.util.Scanner;

class Node<T> {
    private T data;
    private Node<T> next;

    public Node() {
        next = null;
    }

    public Node(T data) {
        this();
        this.data = data;
    }

    public Node(T data, Node<T> next) {
        this();
        this.data = data;
        this.next = next;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public Node<T> getNext() {
        return next;
    }

    public void setNext(Node<T> next) {
        this.next = next;
    }

    @Override
    public String toString() {
        return "{" + data + "}----";
    }
}

class LinkedList<T> {
    private Node<T> head;

    public LinkedList() {
        head = null;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void addFirst(Node<T> n) {
        n.setNext(head);
        head = n;
    }

    public void addLast(Node<T> v) {
        if (isEmpty()) {
            head = v;
            return;
        }
        Node<T> start = head;
        while (start.getNext() != null) {
            start = start.getNext();
        }
        start.setNext(v);
    }

    public void addAfter(int index, Node<T> p) {
        Node<T> temp = head;
        for (int i = 1; i < index; i++) {
            temp = temp.getNext();
            if (temp == null) {
                System.out.println("Less than " + index + " nodes in the list");
                return;
            }
        }
        p.setNext(temp.getNext());
        temp.setNext(p);
        System.out.println("Successfully added after index " + index);
    }

    public void deleteFirst() {
        if (isEmpty()) {
            System.out.println("The list is empty");
            return;
        }
        head = head.getNext();
    }

    public void deleteLast() {
        if (isEmpty()) {
            System.out.println("The list is empty");
            return;
        }
        if (head.getNext() == null) { 
            head = null;
            return;
        }
        Node<T> f = head;
        while (f.getNext().getNext() != null) {
            f = f.getNext();
        }
        f.setNext(null);
    }

    public void deleteAfter(int index) {
        Node<T> temp = head;
        for (int i = 1; i < index; i++) {
            temp = temp.getNext();
            if (temp == null || temp.getNext() == null) {
                System.out.println("Less than " + index + " nodes in the list");
                return;
            }
        }
        temp.setNext(temp.getNext().getNext());
        System.out.println("Successfully deleted after index " + index);
    }

    public Node<T> search(T value) {
        Node<T> current = head;
        while (current != null) {
            if (current.getData().equals(value)) {
                return current;
            }
            current = current.getNext();
        }
        return null; 
    }

    public void print() {
        if (isEmpty()) {
            System.out.println("The list is empty");
            return;
        }
        Node<T> n = head;
        while (n != null) {
            System.out.print(n);
            n = n.getNext();
        }
        System.out.println("null");
    }

   
    public void create() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of nodes to create:");
        int count = sc.nextInt();
        for (int i = 0; i < count; i++) {
            System.out.println("Enter data for node " + (i + 1) + ":");
            T data = (T) sc.next(); 
           addLast(new Node<T>(data));
        }
    }
}

public class LinkedList1 {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
      
        LinkedList<String> list = new LinkedList<String>();

        
         for(int j = 1 ; j <=8 ;j++){   
       
        System.out.println("Operation of linked list");
        System.out.println("******************************************");
        System.out.println("[01] - create linkList");
        System.out.println("[02] - print  ");
        System.out.println("[03] - addFist");    
        System.out.println("[04] - addList ");
        System.out.println("[05] - add after node ");
        System.out.println("[06] - deleteFirst ");
        System.out.println("[07] - deleteLast ");          
        System.out.println("[08] - delete after node ");
        System.out.println("[09] - Search "); 
      
        System.out.println("[0] - Exit ");
        
        
       int t = sc.nextInt();
        
      switch(t){
          case 1:{
              list.create();
        System.out.println("Current List:"); 
              
              break;}
        case 2:{
               list.print();
              
              break;}
        case 3:{
              
        System .out.println("Enter data for first node:");
        String firstData = sc.next();
        list.addFirst(new Node<String>(firstData));

              break;}
        case 4:{
              
        System.out.println("Enter data for last node:");
        String lastData = sc.next();
        list.addLast(new Node<String>(lastData));
              
              break;}
        case 5:{
              
              
        System.out.println("Enter index to add after:");
        int ee = sc.nextInt();
        System.out.println("Enter value for new node:");
        String dataAt = sc.next();
        list.addAfter(ee, new Node<String>(dataAt));

              break;}
        case 6:{
            
            
       
        list.deleteFirst();
        System.out.println("After deleting first node:");
        list.print();



            
            
            break;}
         case 7:{
             
        list.deleteLast();
        System.out.println("After deleting last node:");
        list.print();
             
             break;}
          case 8:{
              
        System.out.println("Enter index to delete after:");
        int deleteIndex = sc.nextInt();
        list.deleteAfter(deleteIndex);
        System.out.println("After deleting after index " + deleteIndex + ":");
        list.print();
              break;}
           case 9:{
               
        System.out.println("Enter value to search:");
        String searchValue = sc.next();
        Node<String> foundNode = list.search(searchValue);
        if (foundNode != null) {
            System.out.println("Found node: " + foundNode);
        }else {
            System.out.println("Node not found.");
        }
               break;}   
           case 0:{
               System.exit(0);
            break;}
          default :{
              System.out.println("Choose an Error,Choose again");
          
          }      
      }}
        
        
        
    }
}

