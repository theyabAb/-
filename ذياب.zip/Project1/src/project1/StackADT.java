
package project1;

import java.util.Scanner;
public class StackADT {
 static Scanner sc =new Scanner (System.in);
 private int stack[];
 private int top;
 
  StackADT(){
 this(10);
 }
public StackADT(int size){
this.stack = new int [size];
this.top = -1;
}
boolean isFull(){
 return top ==stack.length-1; }

boolean isEmpty(){
 return top ==-1;}

void push(int value){
    if (isFull()) {
        System.out.println("stack is full");    
             return; }
    stack[++top] = value;


}

int pop(){

    if (isEmpty()) {
        System.out.println("stack is empty");    
        return -1;
    }
    return(stack[top--]);
}

int peek(){
/*
if (isEmpty()) {
        System.out.println("stack is empty");    
        return -1;
    }
return stack[top];
*/
return (isEmpty()==true?-1:stack[top]);
}/*
int getSize(){
return top+1;

*/
void print(){
    for (int i = top; i >=0; i--){
        System.out.println("{"+stack[i]+"]");     
    }
}
public int getSize(){return top+1;}



void delet(int item){
            if (isEmpty()) {
               System.out.println("stack is empty");    
                  return ;
    }
      StackADT s = new StackADT(this.getSize());
      while(!isEmpty()){
          if (peek()==item) {
              System.out.println("the item is delet"+pop());
              break;
          }
          s.push(pop());
          
          
      
      }
while(!isEmpty()){
push(s.pop());
}

}

void transe(){
      if (isEmpty()) {
         System.out.println("stack is empty");    
              return ;
    }
     StackADT s1 = new StackADT();   
       StackADT s2 = new StackADT(); 
      while(!isEmpty()){
      s1.push(pop());
      }
   while(!s1.isEmpty()){
      s2.push(s1.pop());
      } 
   while(!s2.isEmpty()){
      push(s2.pop());
      }
   
} 

}
