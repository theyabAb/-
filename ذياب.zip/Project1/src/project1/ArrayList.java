
package project1;

import java.util.Scanner;
public class ArrayList {
  static Scanner sc =new Scanner (System.in);
 int curren;
 int data[];
 public ArrayList(){
 this(50);
 
 }
 public  ArrayList(int size) {
 
 curren=-1;
 data = new int[size];
 }
 
 public boolean isFull(){
 return curren ==data.length-1;
 
 
 }
  public boolean isEmpty(){
 return curren ==-1;       
 
  }
public void add(int val) {
    if (isFull()) {
        System.out.println("the array is full");
        return;
    }
        curren++;
        data[curren]=val;

} 
 public void display(){
     if (isEmpty()) {
         System.out.println("the array is empty"); 
         //return;
     }else{
         System.out.println("the element of array");
         for (int i = 0; i <= curren; i++) {
             System.out.println(data[i]+" ");     
         }
     }
  
 } 
 
 public int search(int val){
   if (isEmpty()) {
      System.out.println("the array is empty"); 
        return-1;
 }
 int index = -1;
     for (int i = 0; i < data.length; i++) {
         if (data[i]== val) {
        index=i;
        break;
         }
   
     }
 return index;
 
 } 
 void detel(int item){
 int res =search(item);
     if (res!=-1) {
         
         for (int i = res; i < data.length-1; i++) {
         data[i]=data[i+1];    
         }
    data[curren]=0;
    curren--;
         
     }
     else{
         System.out.println("the element["+item+"] is not fond"); 
     }
}
 
 
 
 int length(){
 return curren+1;
 
 } 
 
 
 
 
 
 
 
 
}
